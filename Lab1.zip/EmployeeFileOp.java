/**
 * Bryant Hernandez
 * CS272
 * 9/1/2019
 * 
 * This class gives an example of reading text files in the following format to an array
 * string_name1	tab	int_number1	tab	string_state1	tab int_zip1	tab	int_age1	tab	string_sex1
 * ...
 * string_namen	tab	int_numbern	tab	string_staten	tab	int_zipn	tab	int_agen	tab	string_sexn
 */

import java.io.*;

// create an Employee class
class Employee{
	String name;
	int number;
	String state;
	int zip;
	int age;
	String sex;
}

public class EmployeeFileOp {
	private static Employee[] numberemployees = null;
	
	public static void read(String fname){
		int no = 0; 
		String line = "";
		try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = new FileReader(fname);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
                //create array
                if(no==-0) {
                	numberemployees = new Employee[301];
                }else{
                	// csv (split at the ',')
                	String[] lineStr = line.split(",");
                	
                	if(no > numberemployees.length){
                		System.out.println("There are too many employees in the file. ");
                		break;
                	}
                	numberemployees[no-1] = new Employee();
                	numberemployees[no-1].name = lineStr[1];
                	numberemployees[no-1].number = Integer.parseInt(lineStr[2]);
                	numberemployees[no-1].state = lineStr[3];
                	numberemployees[no-1].zip = Integer.parseInt(lineStr[4]);
                	numberemployees[no-1].age = Integer.parseInt(lineStr[6]);
                	numberemployees[no-1].sex = lineStr[7];
                }
                no++;
            }   
            bufferedReader.close(); // Always close files.         
        }catch(FileNotFoundException ex) {
            System.out.println("Unable to open file '" +  fname + "'");                
        }catch(IOException ex) {
            System.out.println("Error reading file '" + fname + "'");                  
        }
		System.out.println("Finish reading pairs from file "+ fname);
	}
	
	public static void write(String fname){
		try {
			File file = new File(fname);
			
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			
			// write first row of metadata
			bw.write(numberemployees[0].name+"\t"+numberemployees[0].number+"\t"+numberemployees[0].state+"\t"+numberemployees[0].zip+"\t"+numberemployees[0].age+"\t"+numberemployees[0].sex+"\n");
			// write employees with an age of 30 or less
			for(int i=1;i<numberemployees.length;i++){
				if(numberemployees[i].age <=30)
					bw.write(numberemployees[i].name+"\t"+numberemployees[i].number+"\t"+numberemployees[i].state+"\t"+numberemployees[i].zip+"\t"+numberemployees[i].age+"\t"+numberemployees[i].sex+"\n");
			}
			bw.close();
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("Finish writing pairs to file "+ fname);
	}
	
	public static void main(String[] args) {
		
		numberemployees = null;		//clear the memory
		read("core_dataset.csv");		//read back the 300 employees
		write("young_employee.csv"); //write the employees to another file
	}

}