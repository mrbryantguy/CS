import java.util.Arrays;

// Bryant Hernandez
// CS272

public class EmployeeSet {
	
	// instance variables : array to keep distinct employees, int for all employees
	Employee [] DistinctEmployee;
	int distinctcnt = 0;

	// no argument constructor
	public EmployeeSet() {
		DistinctEmployee = new Employee [10];
	} // end constructor

	// copy constructor
	public EmployeeSet(Object obj) {
		if ((obj != null) && (obj instanceof EmployeeSet)) {
			EmployeeSet set = (EmployeeSet) obj;
			this.DistinctEmployee = new Employee [set.DistinctEmployee.length];
			System.arraycopy(set.DistinctEmployee, 0, this.DistinctEmployee, 0, set.distinctcnt);
			}
		} // end copy constructor
	
	// method to return the actual number of elements
	public int size() {
		return distinctcnt + 1;
	} // end size
	
	// method to return the capacity of DistinctEmployee collection
	public int capacity() {
		return DistinctEmployee.length;
	} // end capacity
	
	// method which adds given Employee object
	// when space is insufficient double the array space using ensureCapacity method
	public void add(Employee a) {
		if ( a != null ) {
			// check for space
			if(distinctcnt == DistinctEmployee.length)
				ensureCapacity(( distinctcnt + 1 ) * 2 );
			
			DistinctEmployee[distinctcnt] = a;
			distinctcnt++;
		} // end if
	} // end add
	
	// method which checks collection for the input parameter
	public boolean contains(Employee a) {
		if (a == null)
			return false;
		else 
			for (int i = 0; i < DistinctEmployee.length; i++) {
				if (DistinctEmployee[i].getNo() == a.getNo())
					return true;
			} // end for
		return false;
	} // end contains

	// method which removes employee with given no eno from the collection
	public boolean remove(int eno) {
		int index;
		for (index = 0; (index < distinctcnt) && (eno != DistinctEmployee[index].getNo()); index++) 
			;
		// not found, return false
		if (index == distinctcnt)
				return false;
		else { // found at DistinctEmployee[index]
			distinctcnt--;
			DistinctEmployee[index] = DistinctEmployee[distinctcnt];
			return true;
		}
	} // end remove
	
	// If this collection’s capacity is smaller than the input parameter, this method sets the capacity to
	// minimumCapacity and enlarges the array to hold minimumCapacity objects
	// Otherwise, this collection is left unchanged.
	private void ensureCapacity(int minimumCapacity) {
		Employee [] tempArray;
		
		if (minimumCapacity > 0) {
			if (DistinctEmployee.length < minimumCapacity) {
				tempArray = new Employee [minimumCapacity];
				System.arraycopy(DistinctEmployee, 0, tempArray, 0, distinctcnt);
				DistinctEmployee = tempArray;
			} // end if
		} // end precondition
	} // end ensureCapacity
	
	// method which adds one employee object to the EmployeeSet such that the objects in the employee array
	// are in ascending order of employee nos; when space insufficient double the array size using ensureCapacity
	public void addOrdered(Employee a) {
		if ( a != null ) {
		// sort employee no
		Employee temp = new Employee(a);
		for (int i = 0; i < DistinctEmployee.length; i++) {
			for (int j = 1; j< (DistinctEmployee.length - 1); j++) {
				if (DistinctEmployee[j-1].getNo() > DistinctEmployee[j].getNo()) {
					// swap
					temp = DistinctEmployee[j-1];
					DistinctEmployee [j-1] = DistinctEmployee[j];
					DistinctEmployee [j] = temp;
				} // end if
			}
		} // end swap
		
		// add employee object
			// check for space
			if(distinctcnt == DistinctEmployee.length)
				ensureCapacity(( distinctcnt + 1 ) * 2 );
			
			// add object
			DistinctEmployee[distinctcnt] = a;
			// check for order
			for (int i = distinctcnt; i >= 0; i-- ) {
				temp = new Employee(a);
				if (DistinctEmployee[i-1].getNo() > DistinctEmployee[i].getNo()) {
					// swap
					temp = DistinctEmployee[i-1];
					DistinctEmployee [i-1] = DistinctEmployee[i];
					DistinctEmployee [i] = temp;
				} // end if
			} // end for
			distinctcnt++;
		} // end if
	} // end addOrdered
	
	@Override
	public String toString() {
		return "EmployeeSet [DistinctEmployee=" + Arrays.toString(DistinctEmployee) + ", distinctcnt=" + distinctcnt
				+ "]";
	}
	
	/*
	static void read(String fname){
		Employee [] corecsv = null;
		int no = 0;
		String line = "";
		try {
		            // FileReader reads text files in the default encoding.
		            FileReader fileReader = new FileReader(fname);

		            // Always wrap FileReader in BufferedReader.
		            BufferedReader bufferedReader = new BufferedReader(fileReader);

		            while((line = bufferedReader.readLine()) != null) {
		                //create array
		                if(no==0) {
		                 corecsv = new Employee [301];
		                }
		                else{
		                 // csv (split at the ',')
		                 String[] lineC = line.split(",");
		                 // since names include comma, split at the quotation marks
		                 String[] lineQ = line.split("\"");
		                 
		                 if(no > corecsv.length){
		                  System.out.println("There are too many employees in the file. ");
		                  break;
		                 }
		                 
		                 corecsv[no-1] = new Employee();
		                 corecsv[no-1].setName(lineQ[1]);
		                 corecsv[no-1].setNo(Integer.parseInt(lineC[2]));
		                 corecsv[no-1].setState(lineC[3]);
		                 corecsv[no-1].setZip(Integer.parseInt(lineC[4]));
		                 corecsv[no-1].setAge(Integer.parseInt(lineC[6]));
		                }
		                no++;
		            } 
		            
		            bufferedReader.close(); // Always close files.        
		        }catch(FileNotFoundException ex) {
		            System.out.println("Unable to open file '" +  fname + "'");                
		        }catch(IOException ex) {
		            System.out.println("Error reading file '" + fname + "'");                  
		        }
		 System.out.println("Finish reading pairs from file "+ fname);
		}
		*/
	
	public static void main(String[] args) {
		
		/*
		Employee[] corecsv = null;
		
		// read in core_dataset.csv
		read("core_dataset.csv");
		
		// create EmployeeSet for coredataset
		EmployeeSet core = new EmployeeSet();
		
		// add in data from corecsv
		for (int i = 0; i < corecsv.length; i++) {
			core.addOrdered(corecsv[i]);
		}
		*/
		
		// test no argument constructor
		EmployeeSet set1 = new EmployeeSet();
		
		// create employees to add
		Employee Zach = new Employee(); Zach.setName("Zach"); Zach.setNo(3564); Zach.setAge(31); Zach.setState("CO"); Zach.setZip(80504); Zach.setAdvisors(43, 7, 82);
		Employee Tyler = new Employee(); Tyler.setName("Tyler"); Tyler.setNo(648); Tyler.setAge(25); Tyler.setState("NM"); Tyler.setZip(88240); Tyler.setAdvisors(516, 55, 3);
		Employee Juan = new Employee(); Juan.setName("Juan"); Juan.setNo(458); Juan.setAge(26); Juan.setState("TX"); Juan.setZip(66548); Juan.setAdvisors(37, 47, 2);
		Employee Dylan = new Employee(); Dylan.setName("Dylan"); Dylan.setNo(4361); Dylan.setAge(28); Dylan.setState("CO"); Dylan.setZip(80555); Dylan.setAdvisors(4, 7, 8);
		
		// add to set1
		set1.add(Zach);
		set1.add(Tyler);
		set1.add(Juan);
		set1.add(Dylan);
		// print
		System.out.println(set1.toString());
		
		// test copy constructor
		EmployeeSet set2 = new EmployeeSet(set1);
		
		// remove Dylan from set2
		set2.remove(4361);
		
		// add back ordered
		set1.addOrdered(Dylan);
		// print
		System.out.println(set2.toString());
		
		// test size 
		System.out.println("The size of set1 is " + set1.size());
		
		// test capacity
		System.out.println("The capacity of set2 is " + set2.capacity());

		
	} // end main
	
} // end class